import supabase from "../config/supabaseClient.js";

// ================= ADD MARKS =================
export const addMarks = async (data) => {
  const { student_id, subject_id, teacher_id, marks, exam_type } = data;

  const { data: result, error } = await supabase
    .from("marks")
    .insert([
      {
        student_id,
        subject_id,
        teacher_id,
        marks,
        exam_type,
      },
    ])
    .select()
    .single();

  if (error) throw error;
  return result;
};

// ================= GET MARKS BY STUDENT =================
export const getMarksByStudent = async (student_id) => {
  const { data, error } = await supabase
    .from("marks")
    .select("*")
    .eq("student_id", student_id);

  if (error) throw error;
  return data;
};