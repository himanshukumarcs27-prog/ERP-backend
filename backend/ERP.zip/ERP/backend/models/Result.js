import supabase from "../config/supabaseClient.js";

// 🔹 Get marks of a student
export const getMarksByStudent = async (student_id) => {
  const { data, error } = await supabase
    .from("marks")
    .select("marks_obtained")
    .eq("student_id", student_id);

  if (error) throw error;
  return data;
};

// 🔹 Get students of a class
export const getStudentsByClass = async (class_id) => {
  const { data, error } = await supabase
    .from("students")
    .select("id")
    .eq("class_id", class_id);

  if (error) throw error;
  return data;
};

// 🔹 Save results
export const saveResults = async (results) => {
  const { data, error } = await supabase
    .from("results")
    .upsert(results);

  if (error) throw error;
  return data;
};

// 🔹 Get result by student
export const getResultByStudent = async (student_id) => {
  const { data, error } = await supabase
    .from("results")
    .select("*")
    .eq("student_id", student_id)
    .single();

  if (error) throw error;
  return data;
};