import express from "express";
import {
  addTeacher,
  fetchTeachers,
  getTeacherProfile,
} from "../controllers/teacherController.js";

import { verifyToken, authorizeRoles } from "../middleware/authMiddleware.js";

const router = express.Router();

// ➕ Add teacher
router.post("/add", addTeacher);

// 📋 Get all teachers
router.get("/", fetchTeachers);

// 👤 Teacher profile (JWT required)
router.get("/me", verifyToken, getTeacherProfile);

export default router;