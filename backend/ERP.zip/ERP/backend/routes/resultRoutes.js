import express from "express";
import {
  generateClassResult,
  getMyResult,getLeaderboard,getSubjectGraph ,
} from "../controllers/resultController.js";





const router = express.Router();

// 🔥 Generate result for whole class
router.post("/generate-class", generateClassResult);

// 🔍 Get result of single student
router.get("/:student_id", getMyResult);
router.get("/leaderboard", getLeaderboard);
router.get("/subject-graph", getSubjectGraph);


export default router;