import express from "express";
import { addMarksController } from "../controllers/markController.js";
import { verifyToken, authorizeRoles } from "../middleware/authMiddleware.js";

const router = express.Router();

// 🔥 Teacher only
router.post(
  "/add",
  verifyToken,
  authorizeRoles("teacher"),
  addMarksController
);

export default router;