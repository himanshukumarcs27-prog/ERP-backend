import {
  createTeacher,
  getAllTeachers,
  getTeacherByEmail,
} from "../models/Teacher.js";

// ================= ADD TEACHER =================
export const addTeacher = async (req, res) => {
  try {
    const teacher = await createTeacher(req.body);

    res.status(201).json({
      message: "Teacher created successfully",
      teacher,
    });
  } catch (error) {
    res.status(500).json({
      message: error.message,
    });
  }
};

// ================= GET ALL TEACHERS =================
export const fetchTeachers = async (req, res) => {
  try {
    const teachers = await getAllTeachers();

    res.status(200).json(teachers);
  } catch (error) {
    res.status(500).json({
      message: error.message,
    });
  }
};

// ================= GET TEACHER PROFILE =================
export const getTeacherProfile = async (req, res) => {
  try {
    const email = req.user.email; // JWT se aa raha hai

    const teacher = await getTeacherByEmail(email);

    res.status(200).json(teacher);
  } catch (error) {
    res.status(500).json({
      message: error.message,
    });
  }
};