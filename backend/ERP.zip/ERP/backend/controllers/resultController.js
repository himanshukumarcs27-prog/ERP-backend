import {
  getMarksByStudent,
  getStudentsByClass,
  saveResults,
  getResultByStudent,
} from "../models/Result.js";

// 🎯 Relative Grade Function
const getRelativeGrade = (rank, total) => {
  const percentile = (rank / total) * 100;

  if (percentile <= 5) return "A+";
  if (percentile <= 15) return "A";
  if (percentile <= 25) return "B+";
  if (percentile <= 40) return "B";
  if (percentile <= 60) return "C";
  if (percentile <= 80) return "D";
  return "F";
};

// 🎯 GPA mapping
const gradeToGPA = {
  "A+": 10,
  "A": 9,
  "B+": 8,
  "B": 7,
  "C": 6,
  "D": 5,
  "F": 0,
};

// ================= GENERATE CLASS RESULT =================
export const generateClassResult = async (req, res) => {
  try {
    const { class_id } = req.body;

    const students = await getStudentsByClass(class_id);

    let results = [];

    // 1️⃣ Calculate total marks
    for (let student of students) {
      const marks = await getMarksByStudent(student.id);

      let total = 0;
      marks.forEach((m) => (total += m.marks_obtained));

      const maxMarks = marks.length * 100;
      const percentage = (total / maxMarks) * 100;

      results.push({
        student_id: student.id,
        total_marks: total,
        percentage,
      });
    }

    // 2️⃣ Sort (descending)
    results.sort((a, b) => b.total_marks - a.total_marks);

    const totalStudents = results.length;

    // 3️⃣ Assign grade + GPA
    const finalResults = results.map((student, index) => {
      const rank = index + 1;
      const grade = getRelativeGrade(rank, totalStudents);

      return {
        student_id: student.student_id,
        total_marks: student.total_marks,
        percentage: student.percentage,
        grade,
        gpa: gradeToGPA[grade],
      };
    });

    // 4️⃣ Save
    await saveResults(finalResults);

    res.json({
      message: "Class result generated successfully",
      data: finalResults,
    });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// ================= GET SINGLE RESULT =================
export const getMyResult = async (req, res) => {
  try {
    const { student_id } = req.params;

    const result = await getResultByStudent(student_id);

    res.json(result);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};
export const getLeaderboard = async (req, res) => {
  try {
    const { class_id } = req.query;

    // 1️⃣ Join students + results
    const { data, error } = await supabase
      .from("results")
      .select(`
        student_id,
        total_marks,
        percentage,
        grade,
        students(name, class_id)
      `)
      .eq("students.class_id", class_id)
      .order("total_marks", { ascending: false })
      .limit(10);

    if (error) throw error;

    // 2️⃣ Add rank
    const leaderboard = data.map((student, index) => ({
      rank: index + 1,
      name: student.students.name,
      total_marks: student.total_marks,
      percentage: student.percentage,
      grade: student.grade,
    }));

    res.json({
      message: "Leaderboard fetched",
      data: leaderboard,
    });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};
// ================= SUBJECT GRAPH =================
export const getSubjectGraph = async (req, res) => {
  try {
    const { subject_id, class_id } = req.query;

    // 1️⃣ Get marks + student name
    const { data, error } = await supabase
      .from("marks")
      .select(`
        marks_obtained,
        student_id,
        students(name, class_id)
      `)
      .eq("subject_id", subject_id)
      .eq("students.class_id", class_id);

    if (error) throw error;

    // 2️⃣ Format for graph
    const graphData = data.map((item) => ({
      name: item.students.name,
      marks: item.marks_obtained,
    }));

    res.json({
      message: "Graph data ready",
      data: graphData,
    });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};