import bcrypt from "bcryptjs";
import { findUserByEmail, createUser } from "../models/User.js";
import { createStudent } from "../models/Student.js"; // ✅ NEW

export const register = async (req, res) => {
  try {
    let { email, password, role, name, roll_no, course, semester } = req.body;

    email = email.trim().toLowerCase();

    if (!email.endsWith("@iilm.edu.com")) {
      return res.status(400).json({ message: "Invalid college email" });
    }

    const existingUser = await findUserByEmail(email);

    if (existingUser.data) {
      return res.status(400).json({ message: "User already exists" });
    }

    const hashedPassword = await bcrypt.hash(password, 10);

    // ✅ 1. Create user
    const { data: userData, error: userError } = await createUser({
      email,
      password: hashedPassword,
      role
    });

    if (userError) throw userError;

    const user = userData[0];

    // ✅ 2. If student → create student profile
    if (role === "student") {
      const { error: studentError } = await createStudent({
        user_id: user.id,
        roll_no,
        name,
        course,
        semester
      });

      if (studentError) throw studentError;
    }

    res.status(201).json({
      message: "User + Student created successfully",
      user
    });

  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

import jwt from "jsonwebtoken";
console.log("LOGIN API HIT");

export const login = async (req, res) => {
  try {
    let { email, password } = req.body;

    email = email.trim().toLowerCase();

    const { data: user, error } = await findUserByEmail(email);

    if (error) {
      return res.status(500).json({ message: error.message });
    }

    if (!user) {
      return res.status(400).json({ message: "User not found" });
    }

    const isMatch = await bcrypt.compare(password, user.password);

    if (!isMatch) {
      return res.status(400).json({ message: "Invalid password" });
    }

    // ✅ FIXED TOKEN
    const token = jwt.sign(
      {
        id: user.id,
        role: user.role
      },
      process.env.JWT_SECRET,
      { expiresIn: "1d" }
    );

    console.log("TOKEN:", token);
    console.log("SECRET:", process.env.JWT_SECRET);

    res.json({
      message: "Login successful",
      token,
      role: user.role
    });
    console.log("VERIFY SECRET:", process.env.JWT_SECRET);

  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};