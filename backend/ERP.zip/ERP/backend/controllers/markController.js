import { addMarks } from "../models/Marks.js";
import supabase from "../config/supabaseClient.js";

export const addMarksController = async (req, res) => {
  try {
    const { student_id, subject_id, marks, exam_type } = req.body;

    // 🔥 FIXED PART
    const { data: teacher, error } = await supabase
      .from("teachers")
      .select("id")
      .eq("user_id", req.user.id)
      .single();

    if (error || !teacher) {
      return res.status(404).json({
        message: "Teacher not found",
      });
    }

    const teacher_id = teacher.id;

    // 🔥 insert marks
    const newMarks = await addMarks({
      student_id,
      subject_id,
      teacher_id,
      marks,
      exam_type,
    });

    res.status(201).json({
      message: "Marks added successfully",
      data: newMarks,
    });
  } catch (error) {
    res.status(500).json({
      message: error.message,
    });
  }
};